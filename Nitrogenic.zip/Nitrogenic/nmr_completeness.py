
import os

if __name__ == "main":
    for subdir, dirs, files in os.walk("."):
        if subdir == ".": continue
        if not "1H.csv" in files:
            print("1H not found in " + subdir)
        if not "13C.csv" in files:
            print("13C not found in " + subdir)
  
    

